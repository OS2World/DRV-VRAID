/*
 * $Source: e:/source/driver/sleep/RCS/dsl.c,v $
 * $Revision: 1.1 $
 * $Date: 1997/02/06 01:25:42 $
 * $Author: vitus $
 *
 * Displays and/or modifies device sleeping timers.  Sample
 * application.
 * Compile with...
 * IBM CSet++ 2.1	- icc -Q -W2all -O [-Gd] dsl.c
 * GNU C 2.7.0		- gcc -Wall -O3 [-Zcrtdll] dsl.c
 * WatCom C/C++ 10.5	- wcl386 -zq -bt=os2v2 -3s -wx -oax dsl.c
 *
 * $Log: dsl.c,v $
 * Revision 1.1  1997/02/06 01:25:42  vitus
 * Initial revision
 *
 */
static char vcid[]="$Id: dsl.c,v 1.1 1997/02/06 01:25:42 vitus Exp $";

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define INCL_DOS
#include <os2.h>

#include "dskslpub.h"




#define DEVICENAME	"dsleeps$"		/* DSKSLEEP.FLT is actual... */


/*
 * Global variables
 */
char	szPrgName[_MAX_PATH];
char	fVerbose = 0;



void
usage(void)
{
    printf("usage: %s [-?] a1,d1,t1 a2,d2,t2 ...\n", szPrgName );
}
void
help(void)
{
    usage();
    printf("\nDisplays and/or changes sleeping times\n"
	   " -?\tthis text\n\n"
	   " a,d,m\tselects new timeout value ('m' minutes) for device 'd' on adapter 'a'\n");
}




/*#
 * NAME
 *	DisplayVersion
 * CALL
 *	DisplayVersion(hd)
 * PARAMETER
 *	hd		handle to open device
 * RETURNS
 *	OS error code
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Displays driver version.
 * REMARKS
 */
int
DisplayVersion(HFILE hd)
{
    APIRET	rc;
    USHORT	version = 0;
    ULONG	datasize = sizeof(version);

    /* Issue IOCtl, version will be returned in 16bits */

    rc = DosDevIOCtl( hd, IOCTL_DSKSLEEP_CATEGORY, DSKSL_QUERY_VERSION,
		     NULL, 0, NULL,
		     &version, datasize, &datasize );

    if( rc )
	fprintf(stderr,"DSKSL_QUERY_VERSION - error %lu\n",rc);
    else
	printf("Installed: DSKSLEEP.FLT %u.%02u\n",
	       HIBYTE(version), LOBYTE(version) );

    return (int)rc;
}




/*#
 * NAME
 *	DisplaySettings
 * CALL
 *	DisplaySettings(hd)
 * PARAMETER
 *	hd		handle to open device
 * RETURNS
 *	OS error code
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Displays all devices and timeout values.
 * REMARKS
 */
int
DisplaySettings(HFILE hd)
{
    APIRET	    rc;
    ULONG	    datasize = 4 + 40 * sizeof(DEVICE_TIMEOUT);
    PDSKSL_QL_DATA  data = malloc( datasize );
    unsigned	    i;

    if( data == NULL )
    {
	fprintf(stderr,"out of memory\n");
	return -3;
    }

    rc = DosDevIOCtl( hd, IOCTL_DSKSLEEP_CATEGORY, DSKSL_QUERY_TIMEOUT,
		     NULL, 0, NULL,
		     data, datasize, &datasize );

    if( rc )
	fprintf(stderr,"DSKSL_QUERY_TIMEOUT - error %lu\n",rc);
    else
    {
	/* Calculate number of entries. */

	unsigned cnt = ((data->cb > datasize ?
			datasize : data->cb)
			- FIELDOFFSET(DSKSL_QL_DATA,list))
			 / sizeof(data->list[0]);

	/* Display nice table */

	printf(" Adapter Unit\tMinutes\n");
	for( i = 0; i < cnt; ++i )
	    printf(" %3u\t %3u\t %4lu\n",
		   data->list[i].adapter, data->list[i].unit,
		   data->list[i].minutes );
    }

    free( data );
    return (int)rc;
}


		 

/*#
 * NAME
 *	ChangeSetting
 * CALL
 *	ChangeSetting(hd,a,d,m)
 * PARAMETER
 *	a		adapter index
 *	d		unit index
 *	m		minutes before sleep (0: never)
 * RETURNS
 *	OS error code
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Changes the timeout value for a single device.
 * REMARKS
 */
int
ChangeSetting(HFILE hd,UCHAR a,UCHAR d,ULONG m)
{
    APIRET		rc;
    ULONG		parmsize = sizeof(DSKSL_SETTO_PARM);
    DSKSL_SETTO_PARM	parm;

    if( fVerbose )
	printf("--- new: %u %u %lu\n",a,d,m);

    parm.cb = (USHORT)parmsize;
    parm.reserved[0] = parm.reserved[1] = 0;
    parm.list[0].adapter = a;
    parm.list[0].unit = d;
    parm.list[0].minutes = m;
    parm.list[0].reserved[0] = parm.list[0].reserved[1] = 0;

    rc = DosDevIOCtl( hd, IOCTL_DSKSLEEP_CATEGORY, DSKSL_SET_TIMEOUT,
		     &parm, parmsize, &parmsize,
		     NULL, 0, NULL );
    if( rc )
	fprintf(stderr,"DSKSL_SET_TIMEOUT - error %lu\n",rc);
    return (int)rc;
}




/*#
 * NAME
 *	main
 * CALL
 *	main(argc,argv)
 * PARAMETER
 *	argc,argv	as usual
 * RETURNS
 *	0		OK
 *	/0		some error
 * GLOBAL
 *	szPrgName, fVerbose
 * DESPRIPTION
 *	Main routine, parses parameter and calls requested
 *	subfunctions.
 * REMARKS
 */
int
main(int argc,char *argv[])
{
    HFILE	hd = 0;
    ULONG	action_taken;
    APIRET	rc;
    int		result;

    strcpy( szPrgName, argv[0] );
    while( argc > 1  &&  argv[1][0] == '-' )
    {
	switch( argv[1][1] )
	{
	  case '?':
	    help();
	    return 0;

	  case 'v':
	    fVerbose = 1;
	    break;

	  default:
	    printf("%s: unknown arg \"%s\"\n", szPrgName, argv[1] );
	    return -1;
	}
	--argc;
	++argv;
    }

    /* Open device driver, no special settings.  Use DENYNONE
     * so other processes (daemon?) may open concurrently. */

    rc = DosOpen( DEVICENAME, &hd, &action_taken,
		 0, 0,
		 OPEN_ACTION_FAIL_IF_NEW|OPEN_ACTION_OPEN_IF_EXISTS,
		 OPEN_SHARE_DENYNONE|OPEN_ACCESS_READWRITE,
		 NULL );
    if( rc )
    {
	fprintf(stderr,"DosOpen(%s) - error %lu\n",DEVICENAME,rc);
	result = (int)rc;
    }
    else
    {
	DisplayVersion( hd );			/* always display version */
	if( argc == 1 )				/* no argument: display */
	{
	    printf("Current settings:\n");
	    result = DisplaySettings( hd );
	}
	else					/* at least one triple */
	{
	    printf("Current settings:\n");
	    result = DisplaySettings( hd );

	    for(; argc > 1; --argc,++argv )
	    {
		unsigned a = 0xFF, d = 0xFF;	/* dsksleep won't find them... */
		ULONG	 m = 0;

		/* Parse argument (spaces important!) and
		 * call ChangeSetting(). */

		sscanf( argv[1], "%u ,%u ,%lu", &a, &d, &m );
		result = ChangeSetting( hd, (UCHAR)a, (UCHAR)d, m );
	    }
	    printf("After changing:\n");
	    result = DisplaySettings( hd );
	}

	DosClose( hd );				/* be a nice guy */
    }

    return result;
}
