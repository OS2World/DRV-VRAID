/*
 * $Source: e:/source/driver/sleep/RCS/iorb.c,v $
 * $Revision: 1.9 $
 * $Date: 1997/08/23 22:26:24 $
 * $Author: vitus $
 *
 * Request Time processing	- Timer processing
 *
 * DDK says we have to saved SI,DI,DS,ES but all code I've seen
 * only uses 'loadds' restoring only SI,DI,DS (and remember: CorelSCSI
 * even changed DS!).  Nevertheless I will do a '_saveregs' now and
 * save/restore all registers when calling other drivers...
 *
 * $Log: iorb.c,v $
 * Revision 1.9  1997/08/23 22:26:24  vitus
 * Saves status and sense values in device structure (IOCtl retrieves)
 * IssueStart now used by INIT code, too
 *
 * Revision 1.8  1997/06/18 00:54:29  vitus
 * - preserve registers when calling other drivers
 *   or being called from others
 * - use SAVE_IF,RESTORE_IF to restore interrupt flag
 *
 * Revision 1.7  1997/05/11 01:57:44  vitus
 * - switched from Block/Run to IORB queues (aka HPFS386 problem)
 * - added debugging messages
 *
 * Revision 1.6  1997/04/27 22:30:34  vitus
 * Added retries if START+TEST failed
 * StartComplete: beeps if TEST failed
 * StartComplete: flag updates after FreeIorb
 *
 * Revision 1.5  1997/03/03 23:41:27  vitus
 * StartComplete: issue TEST UNIT READY after START
 * StartComplete: only successfull TEST UNIT READY resets flags
 *
 * Revision 1.4  1996/11/03 23:39:57  vitus
 * Use timeout from device structure instead of global
 *
 * Revision 1.3  1996/10/23 23:41:14  vitus
 * Added pragma to display MS-C warnings
 * Allows retries when stopping a device
 *
 * Revision 1.2  1996/09/30 00:27:56  vitus
 * Removed indirection from pointer calls
 *
 * Revision 1.1  1996/09/27 03:19:52  vitus
 * Initial revision
 * -------------------------------------------
 * This code is Copyright Vitus Jensen 1996-97
 */
static char const id[]="$Id: iorb.c,v 1.9 1997/08/23 22:26:24 vitus Exp $";


#include <string.h>

#define INCL_NOBASEAPI
#define INCL_NOPMAPI
#include <os2.h>

#include <devcmd.h>
#include <devclass.h>

#define INCL_INITRP_ONLY
#include <reqpkt.h>

#include <scsi.h>
#include <iorb.h>
#include <addcalls.h>

#include <dhcalls.h>

#include "dsksleep.h"
#include "dskslpub.h"
#include "proto.h"
#include "extern.h"




/* **********************************************************************
 * **** Debugging Data **************************************************
 * ******************************************************************* */
#if defined(DEBUG)
char _inconst	dszYankQueue[]=		"\r\nYankQueue";
char _inconst	dszQueueIorb[]=		"\r\nQueueIorb";
char _inconst	dszIssueStart[]=	"\r\nIssueStart()";
char _inconst	dszStartComplete[]=	"\r\nStartComplete()";
char _inconst	dszIssueStop[]=		"\r\nIssueStop()";
char _inconst	dszStopComplete[]=	"\r\nStopComplete()";
char _inconst	dszTestFailed[]=	"\r\nTEST UNIT READY failed, error %w";
char _inconst	dszStartFailed[]=	"\r\nSTART UNIT failed, error %w";

char _inconst	dszFilter[]=		"\r\nFilterFunction";
char _inconst	dszIorbConfig[]=	"\r\nCC Configuration";
char _inconst	dszIorbDevtab[]=	"\r\nCM Device Table";
char _inconst	dszCall[]=		"C";
char _inconst	dszReturn[]=		"R";
#endif /* DEBUG */






/* **********************************************************************
 * **** Allocation of per device IORB ***********************************
 * ******************************************************************* */

/*
 * NAME
 *	AllocateIorb
 * CALL
 *	AllocateIorb(device)
 * PARAMETER
 *	device		IORB for this device
 * RETURNS
 *	/0		allocated IORB
 *	0		no IORB available
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Simple, as there is only a single IORB to allocate from.
 * REMARKS
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PRIVATE NPVOID NEAR
AllocateIorb(NPDEVICE const device)
{
    NPVOID np = 0;

    SAVE_IF();
    DISABLE();
    if( device->iorb_busy == 0 )
    {
	device->iorb_busy = 1;
	np = &device->iorb;
    }
    RESTORE_IF();
    return np;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif




/*
 * NAME
 *	FreeIorb
 * CALL
 *	FreeIorb(device)
 * PARAMETER
 *	device		device to stop
 * RETURNS
 *	nothing
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Frees previously allocated IORB.
 * REMARKS
 */
PRIVATE void NEAR
FreeIorb(NPDEVICE device)
{
    device->iorb_busy = 0;
    return;
}






/* **********************************************************************
 * **** Code to queue/dequeue IORBs *************************************
 * ******************************************************************* */

typedef union {
    PIORB	next;
    UCHAR	dummy[ADD_WORKSPACE_SIZE];
} ADDWS, FAR * PADDWS;



/*#
 * NAME
 *	QueueIorb
 * CALL
 *	QueueIorb(device,iorb)
 * PARAMETER
 *	device		stopped device
 *	iorb		IORB or IORB chain from DMD
 * RETURNS
 *	nothing
 * GLOBAL
 *	none
 * PURPOSE
 *	Adds 'iorb' to per device queue of 'to-be-restarted'
 *	IORB (chains).
 * REMARKS
 *	Don't use 'iorb->pNxtIORB' (designed to let ADD build
 *	IORB chains) as we would have to seperate IORB types
 *	when yanking the queue to the ADD (see DDK inf).
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PRIVATE void NEAR
QueueIorb(NPDEVICE const device,PIORB const iorb)
{
    DEBMSG(dszQueueIorb);
    _far_memset(iorb->ADDWorkSpace, 0, ADD_WORKSPACE_SIZE);

    SAVE_IF();
    DISABLE();					/* do not disturb */
    if( device->pQueueHead == NULL )		/* empty queue? */
	device->pQueueHead = iorb;
    else
    {
	PADDWS const ws = (PADDWS)device->pQueueFoot->ADDWorkSpace;
	ws->next = iorb;
    }
    device->pQueueFoot = iorb;
    RESTORE_IF();
    return;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif




/*#
 * NAME
 *	YankQueue
 * CALL
 *	YankQueue(device)
 * PARAMETER
 *	device		our device structure
 * RETURNS
 *	nothing
 * GLOBAL
 *	none
 * PURPOSE
 *	Passes all saved IORBs for this device to it's ADD.
 * REMARKS
 *	Only pass a single IORB at a time if not IOCC_EXECUTE_IO
 *	CommandCode (see DDK inf).
 *	For safety: clear used bytes in ADDWorkSpace.
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PRIVATE void NEAR
YankQueue(NPDEVICE const device)
{
    PIORB iorb;

    DEBMSG(dszYankQueue);
    SAVE_IF();
    DISABLE();
    while( (iorb=device->pQueueHead) != NULL )
    {
	PADDWS const ws = (PADDWS)iorb->ADDWorkSpace;

	/* Set 'pQueueHead' to next IORB to remove an IORB from
	 * our queue and clear anything left in ADDWorkSpace. */

	if( (device->pQueueHead=ws->next) == NULL )
	    device->pQueueFoot = NULL;
	ws->next = NULL;

	/* Make sure the correct unit handle is set and
	 * call ADD. */

	iorb->UnitHandle = device->hdADDUnit;
	device->counter = 0;			/* reset counter */

	SAVE_REGS();
	(device->pADDEntry)(iorb);
	RESTORE_REGS();

	DISABLE();				/* ADD may have changed */
    }
    RESTORE_IF();

    return;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif






/* **********************************************************************
 * **** Task Time Processing (filter) ***********************************
 * ******************************************************************* */


/*
 * NAME
 *	StartComplete
 * CALL
 *	StartComplete(iorb)
 * PARAMETER
 *	iorb		request completed
 * RETURNS
 *	(nothing)
 * GLOBAL
 *	(none)
 * DESPRIPTION
 *	Called when the ADD completed a START UNIT command.
 *	Updates flags and unblocks waiting threads.
 *	Any unblocking/clearing of flags will be done *after* TEST
 *	UNIT READY verified a correct working drive!
 * REMARKS
 *	Do retries make any sense?
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PRIVATE void FAR _saveregs _loadds
StartComplete(PIORB iorb)
{
    NPDEVICE		device = *(NPDEVICE FAR *)iorb->DMWorkSpace;
    PIORB_ADAPTER_PASSTHRU ioadp = (PIORB_ADAPTER_PASSTHRU)iorb;

    DEBMSG(dszStartComplete);
    if( ioadp->pControllerCmd[0] == 0x1b )	/* START UNIT ? */
    {
	device->iotype = DSKIO_START;
	device->laststatus = ioadp->iorbh.Status;
	device->lasterror = ioadp->iorbh.ErrorCode;

	if( (ioadp->iorbh.Status & IORB_ERROR) )
	{
	    DEBMSG1(dszStartFailed,ioadp->iorbh.ErrorCode);
	}

	/* Well, target may be in a UNIT ATTENTION state.  Issue
	 * TEST UNIT READY (plus REQUEST SENSE) to clear this state. */

	memset(&device->sensedata, 0, sizeof(SCSI_REQSENSE_DATA));
	memset(&device->statusblock, 0, sizeof(SCSI_STATUS_BLOCK));
	device->statusblock.ReqSenseLen = sizeof(SCSI_REQSENSE_DATA);
	device->statusblock.SenseData = &device->sensedata;

	_far_memset(ioadp, 0, sizeof(IORB_ADAPTER_PASSTHRU));
	ioadp->iorbh.Length =		sizeof(IORB_ADAPTER_PASSTHRU);
	ioadp->iorbh.UnitHandle =	device->hdADDUnit;
	ioadp->iorbh.CommandCode =	IOCC_ADAPTER_PASSTHRU;
	ioadp->iorbh.CommandModifier =	IOCM_EXECUTE_CDB;
	ioadp->iorbh.RequestControl =	IORB_ASYNC_POST | IORB_REQ_STATUSBLOCK;
	ioadp->iorbh.NotifyAddress =	(PIORB (FAR *)())StartComplete;

	ioadp->iorbh.StatusBlockLen =	sizeof(SCSI_STATUS_BLOCK);
	ioadp->iorbh.pStatusBlock =	(NPBYTE)&device->statusblock;

	ioadp->pControllerCmd =		device->cdbTestReady;
	ioadp->ControllerCmdLen =	6;

	*(NPDEVICE FAR *)ioadp->iorbh.DMWorkSpace = device;

	SAVE_REGS();
	(device->pADDEntry)(&ioadp->iorbh);
	RESTORE_REGS();

	/* Will return to this routine after
	 * TEST UNIT READY (else case) */

    } /* end[START STOP UNIT] */
    else					/* TEST UNIT READY */
    {
	device->iotype = DSKIO_TESTREADY;
	device->laststatus = ioadp->iorbh.Status;
	device->lasterror = ioadp->iorbh.ErrorCode;

	if( (ioadp->iorbh.Status & IORB_ERROR) )
	{
	    DEBMSG1(dszTestFailed,ioadp->iorbh.ErrorCode);

	    /* Bad!  What to do?  HELP!!!
	     * We could at least notify the user if he's there... */

	    DevHelp_Beep(440, 500);
	    DevHelp_Beep(300, 1000);

	    FreeIorb(device);			/* So IssueStart may allocate */
	    if( (fDriverFlags & DF_INITDONE) )	/* no retries during /DEBUG */
	    {
		/* There is something more we can do: retry.
		 * If this isn't possible, clear 'blocked' flag
		 * and let next I/O call 'IssueStart'. */

		if( IssueStart(device) )
		    device->blocked = 0;
	    }
	    else
		device->blocked = 0;		/* keep on running */
	}
	else
	{
	    /* TEST UNIT READY completed without errors,
	     * clear 'stopped' flag and reset 'counter' to zero.
	     * Clear flags after 'FreeIorb()', a timer interrupt
	     * may occure during that function. */

	    device->counter = 0;
	    device->stopped = 0;
	    FreeIorb(device);
	    device->blocked = 0;
	    YankQueue(device);			/* restart any queued I/Os */
	}
    } /* end[TEST UNIT READY] */

    return;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif




/*
 * NAME
 *	IssueStart
 * CALL
 *	IssueStart(device)
 * PARAMETER
 *	device		device to start
 * RETURNS
 *	0		START UNIT issued
 *	/0		error, cmd not started
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Builds START STOP UNIT cdb with start bit set
 *	in newly allocated IORB and passes this IORB
 *	to ADD for 'device'.
 *	Set 'blocked' even if already set (init1.c).
 * REMARKS
 *	Uses 'StartComplete' as notification routine.
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PUBLIC int NEAR
IssueStart(NPDEVICE const device)
{
    NPIORB_ADAPTER_PASSTHRU ioadp = AllocateIorb( device );

    DEBMSG(dszIssueStart);
    if( ioadp == NULL )
    {
	return -1;				/* not possible */
    }

    device->blocked = 1;			/* please, no I/Os */

    memset(&device->sensedata, 0, sizeof(SCSI_REQSENSE_DATA));
    memset(&device->statusblock, 0, sizeof(SCSI_STATUS_BLOCK));
    device->statusblock.ReqSenseLen = sizeof(SCSI_REQSENSE_DATA);
    device->statusblock.SenseData = &device->sensedata;

    memset(ioadp, 0, sizeof(IORB_ADAPTER_PASSTHRU));
    ioadp->iorbh.Length =		sizeof(IORB_ADAPTER_PASSTHRU);
    ioadp->iorbh.UnitHandle =		device->hdADDUnit;
    ioadp->iorbh.CommandCode =		IOCC_ADAPTER_PASSTHRU;
    ioadp->iorbh.CommandModifier =	IOCM_EXECUTE_CDB;
    ioadp->iorbh.Timeout =		START_TIMEOUT;
    ioadp->iorbh.RequestControl =	IORB_ASYNC_POST | IORB_REQ_STATUSBLOCK;
    ioadp->iorbh.NotifyAddress =	(PIORB (FAR *)())StartComplete;

    ioadp->iorbh.StatusBlockLen =	sizeof(SCSI_STATUS_BLOCK);
    ioadp->iorbh.pStatusBlock =		(NPBYTE)&device->statusblock;

    ioadp->pControllerCmd =		device->cdbStart;
    ioadp->ControllerCmdLen =		6;

    /* To reconstruct which unit this start command has
     * been issued for save pointer in request.  The DM
     * workspace will never be used by an ADD and is
     * therefore free (there is no DMD either...) */

    *(NPDEVICE FAR *)ioadp->iorbh.DMWorkSpace = device;

    SAVE_REGS();
    (device->pADDEntry)(&ioadp->iorbh);
    RESTORE_REGS();
    return 0;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif




/*
 * NAME
 *	FilterFunction
 * CALL
 *	FilterFunction(iorb)
 * PARAMETER
 *	iorb		request to anylyse
 * RETURNS
 *	nothing
 * GLOBAL
 *	anpUnit
 * DESPRIPTION
 *	Besides returning our own device table (there is none)
 *	this routine checks whether the addressed device is
 *	still running and forwards the request to ADD if it is.
 *	A stopped device is passed to 'IssueStart' and
 *	forwarding waits until the START completed.
 *	To prevent I/Os during START or STOP the routine
 *	checks 'blocked' flag first.
 * REMARKS
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PUBLIC void FAR _saveregs _loadds
FilterFunction(PIORB iorb)
{
    NPDEVICE	device;

    /*DEBMSG(dszFilter);*/

    /* Handle the Get Device Table call.  Since we are just filtering
     * requests, return a table with no unit info. */

    if( iorb->CommandCode == IOCC_CONFIGURATION )
    {
	DEBMSG(dszIorbConfig);
	if( iorb->CommandModifier == IOCM_GET_DEVICE_TABLE )
	{
	    DEBMSG(dszIorbDevtab);
	    ((PIORB_CONFIGURATION)iorb)->pDeviceTable->ADDLevelMajor = 1;
	    ((PIORB_CONFIGURATION)iorb)->pDeviceTable->ADDLevelMinor = 0;
	    ((PIORB_CONFIGURATION)iorb)->pDeviceTable->ADDHandle = hdThisDriver;
	    ((PIORB_CONFIGURATION)iorb)->pDeviceTable->TotalAdapters = 0;
	}

	iorb->ErrorCode = 0;
	iorb->Status = IORB_DONE;

	/* Refering to DDK an ASYNC_POST is not allowed here
	 * (only EXECUTE_IO).  But all samples support it.  So do
	 * as the rest of them. */

	if( (iorb->RequestControl & IORB_ASYNC_POST) )
	{
	    SAVE_REGS();
	    (iorb->NotifyAddress)(iorb);
	    RESTORE_REGS();
	}
	return;
    }

    /* iorb->UnitHandle should be a valid index in
     * our global table.  If not -> tell caller. */

    if( iorb->UnitHandle >= cUnit )
    {
	iorb->ErrorCode = IOERR_UNIT_NOT_ALLOCATED;
	iorb->Status = IORB_DONE | IORB_ERROR;
	if( (iorb->RequestControl & IORB_ASYNC_POST) )
	{
	    SAVE_REGS();
	    (iorb->NotifyAddress)(iorb);
	    RESTORE_REGS();
	}
	return;
    }

    device = anpUnit[iorb->UnitHandle];		/* device structure */


    /* First, there may be a start or stop pending (setting
     * blocked flag):  add this IORB(s) to internal chain and return. */

    SAVE_IF();
    DISABLE();					/* needed? */
    if( device->blocked )
    {
	QueueIorb(device, iorb);		/* StartComplete restarts it */
	RESTORE_IF();
	return;					/* return to caller */
    }


    /* Second, this device may be stopped and has
     * to be started again. */

    if( device->stopped )			/* interrupts still disabled */
    {
	device->blocked = 1;			/* no other I/Os */
	QueueIorb(device, iorb);		/* StartComplete restarts it */
	IssueStart(device);			/* now START! */
	RESTORE_IF();
	return;					/* return to caller */
    }


    /* Call the ADD for any requests which aren't filtered.
     * Replace unit handle for filter with unit handle
     * for the ADD */

    DEBMSG(dszCall);
    iorb->UnitHandle = device->hdADDUnit;
    device->counter = 0;			/* reset counter */
    SAVE_REGS();
    (device->pADDEntry)(iorb);
    RESTORE_REGS();
    DEBMSG(dszReturn);
    RESTORE_IF();
    return;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif






/* **********************************************************************
 * **** Timer Context Processing ****************************************
 * ******************************************************************* */


/*
 * NAME
 *	StopComplete
 * CALL
 *	StopComplete(iorb)
 * PARAMETER
 *	iorb		STOP IORB completed
 * RETURNS
 *	nothing
 * GLOBAL
 *	none
 * DESPRIPTION
 *	see 'StartComplete'
 * REMARKS
 */
PRIVATE void FAR _saveregs _loadds
StopComplete(PIORB iorb)
{
    NPDEVICE const device = *(NPDEVICE FAR *)iorb->DMWorkSpace;

    DEBMSG(dszStopComplete);

    device->iotype = DSKIO_STOP;
    device->laststatus = iorb->Status;
    device->lasterror = iorb->ErrorCode;

    FreeIorb(device);				/* so START can use it */
    device->blocked = 0;			/* OK, do want you want */
    return;
}




/*
 * NAME
 *	IssueStop
 * CALL
 *	IssueStop(device)
 * PARAMETER
 *	device		to stop
 * RETURNS
 *	nothing
 * GLOBAL
 *	none
 * DESPRIPTION
 *	Allocates IORB, fills in START STOP UNIT cdb with
 *	start bit cleared and passes it to ADD.
 * REMARKS
 *	Interrupts disabled!
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PUBLIC void NEAR
IssueStop(NPDEVICE const device)
{
    NPIORB_ADAPTER_PASSTHRU ioadp = AllocateIorb(device);

    DEBMSG(dszIssueStop);

    /* The IORB from unit structure may not be available.
     * STOP while STARTing? */

    if( ioadp != NULL )
    {
	device->stopped = 1;
	device->blocked = 1;			/* please, no I/Os */

	memset(&device->sensedata, 0, sizeof(SCSI_REQSENSE_DATA));
	memset(&device->statusblock, 0, sizeof(SCSI_STATUS_BLOCK));
	device->statusblock.ReqSenseLen = sizeof(SCSI_REQSENSE_DATA);
	device->statusblock.SenseData = &device->sensedata;

	memset(ioadp, 0, sizeof(IORB_ADAPTER_PASSTHRU));
	ioadp->iorbh.Length =		sizeof(IORB_ADAPTER_PASSTHRU);
	ioadp->iorbh.UnitHandle =	device->hdADDUnit;
	ioadp->iorbh.CommandCode =	IOCC_ADAPTER_PASSTHRU;
	ioadp->iorbh.CommandModifier =	IOCM_EXECUTE_CDB;
	ioadp->iorbh.RequestControl =	IORB_ASYNC_POST | IORB_REQ_STATUSBLOCK;
	ioadp->iorbh.NotifyAddress =	(PIORB (FAR *)())StopComplete;

	ioadp->iorbh.StatusBlockLen =	sizeof(SCSI_STATUS_BLOCK);
	ioadp->iorbh.pStatusBlock =	(NPBYTE)&device->statusblock;

	ioadp->pControllerCmd =		device->cdbStop;
	ioadp->ControllerCmdLen =	6;

	/* To reconstruct which unit this stop command has
	 * been issued for save pointer in request.  The DM
	 * workspace will never be used by an ADD and is
	 * therefore free (there is no DMD either...) */

	*(NPDEVICE FAR *)ioadp->iorbh.DMWorkSpace = device;

	SAVE_REGS();
	(device->pADDEntry)(&ioadp->iorbh);
	RESTORE_REGS();
    }

    return;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif




/*
 * NAME
 *	Timer
 * CALL
 *	Timer(void)
 * PARAMETER
 *	none
 * RETURNS
 *	nothing
 * GLOBAL
 *	ulTimer
 *	anpUnit
 * DESPRIPTION
 *	Increments 'counter' in all unit structures
 *	and sends stop if 'counter' reached limit.
 * REMARKS
 *	Called by assembler stub which saves/restores registers
 *	but doesn't enable interrupts.
 */
#if defined(_MSC_VER)
# pragma optimize("lge",off)
#endif
PUBLIC void NEAR
Timer(void)
{
    USHORT i;

    ++ulTimer;					/* free running counter */

    /* Detect unused device */

    for( i = 0; i < cUnit; ++i )
    {
	NPDEVICE const dev = anpUnit[i];

	DISABLE();
	if(  !dev->stopped  &&  dev->usSleep != 0
	   &&  ++dev->counter >= dev->usSleep )
	{
	    dev->counter = dev->usSleep;	/* for IOCtls... */
	    IssueStop(dev);
	}
	ENABLE();
    }

    return;
}
#if defined(_MSC_VER)
# pragma optimize("",on)
#endif
