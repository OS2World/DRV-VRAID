/*
 * $Source: e:/source/driver/sleep/RCS/dsksleep.h,v $
 * $Revision: 1.10 $
 * $Date: 1997/09/03 01:20:51 $
 * $Author: vitus $
 *
 * Types and Constants
 *
 * $Log: dsksleep.h,v $
 * Revision 1.10  1997/09/03 01:20:51  vitus
 * added iotype to device structure (which I/O failed?)
 *
 * Revision 1.9  1997/07/21 01:05:58  vitus
 * Added status buffers to unit structure
 *
 * Revision 1.8  1997/06/18 00:47:37  vitus
 * added [SAVE|RESTORE]_[REGS|IF] macros
 * changed DISABLE,ENABLE to use inline functions
 *
 * Revision 1.7  1997/05/07 23:55:06  vitus
 * added debugging macros and _inconst
 * added IORB queue (head,foot) to device structure
 *
 * Revision 1.6  1997/03/03 01:20:05  vitus
 * added START_TIMEOUT definition
 * added DISPLAYBUFFER_SIZE
 * added TEST UNIT READY cdb and adapter index to device structure
 *
 * Revision 1.5  1997/02/11 23:09:36  vitus
 * Redefine STATUS_ERR_UNKNCMD (incl. STDON)
 *
 * Revision 1.4  1997/02/06 01:04:22  vitus
 * Added STATUS_ERR_* definitions
 * Added FP_* macros
 *
 * Revision 1.3  1996/11/04 00:10:27  vitus
 * Added timeout value to device structure
 *
 * Revision 1.2  1996/10/23 23:35:07  vitus
 * Don't define PRIVATE as static in debug version
 *
 * Revision 1.1  1996/09/27 03:34:16  vitus
 * Initial revision
 * -------------------------------------------
 * This code is Copyright Vitus Jensen 1996-97
 */


/* Tunable constants */

#define MAX_UNITS		24
#define MAX_DEVICETABLE_SIZE	(1*1024)
#define DISPLAYBUFFER_SIZE	(3*1024)

#define START_TIMEOUT		30		/* if defined: force ADD
						   to wait up to n seconds
						   for START UNIT */

#define DRIVERFLAGS		0
#define DRIVERCLASS_ADD		1


#if !defined(DEBUG)
# define PRIVATE	static
#else
# define PRIVATE
#endif
#define PUBLIC

#define _intext 	_based(_segname("_CODE"))
#define _ininit 	_based(_segname("INITDATA"))
#define _inconst 	_based(_segname("_CONST"))
#define	_inldata	_based(_segname("LIBDATA"))



#define SAVE_IF()	_asm{pushf}
#define RESTORE_IF()	_asm{popf}
#define DISABLE()	_disable()
#define ENABLE()	_enable()

#define MK_FP(sel,off)	MAKEP(sel,off)
#define FP_SEL(fp)	SELECTOROF(fp)
#define FP_OFF(fp)	OFFSETOF(fp)
#define SAVE_REGS()	_asm{_asm pusha _asm push ds _asm push es}
#define RESTORE_REGS()	_asm{_asm pop es _asm pop ds _asm popa}



/*
 *	Timer definitions
 *	The driver contains a ticker (ulTimer) which is
 *	allocated and handled through standard OS/2 API.
 *	This 'ulTimer' is referenced for timeout detection.
 *	OBS: all definitions refer to an intervall of 1s!
 */
#define TIMER_TMS	(1*10000U)	/* call intervall [tenths of ms] */
#define SLEEP_TIME	(30*60U)	/* will result device stop [s] */



/* Defined in DDK but for some reason not included */
typedef UCHAR NEAR *NPUCHAR;

/* Missing in DDK */
#undef STATUS_ERR_UNKCMD
#define STDEV			0x4000		/* driver defined error code */
#define STATUS_ERR_UNKUNIT	(STERR | STDON | 0x01)
#define STATUS_ERR_NOTREADY	(STERR | STDON | 0x02)
#define STATUS_ERR_UNKCMD	(STERR | STDON | 0x03)
#define STATUS_ERR_CRC		(STERR | STDON | 0x04)
#define STATUS_ERR_REQLEN	(STERR | STDON | 0x05)
#define STATUS_ERR_SEEK		(STERR | STDON | 0x06)
#define STATUS_ERR_UNKMEDIA	(STERR | STDON | 0x07)
#define STATUS_ERR_NOTFOUND	(STERR | STDON | 0x08)
#define STATUS_ERR_PAPEROUT	(STERR | STDON | 0x09)
#define STATUS_ERR_WRFAULT	(STERR | STDON | 0x0A)
#define STATUS_ERR_RDFAULT	(STERR | STDON | 0x0B)
#define STATUS_ERR_GENERR	(STERR | STDON | 0x0C)
#define STATUS_ERR_CHGDISK	(STERR | STDON | 0x0D)
#define STATUS_ERR_UNCERTAIN	(STERR | STDON | 0x10)
#define STATUS_ERR_INTERRUPTED	(STERR | STDON | 0x11)
#define STATUS_ERR_NOMONITOR	(STERR | STDON | 0x12)
#define STATUS_ERR_INVPARAM	(STERR | STDON | 0x13)
#define STATUS_ERR_DEVINUSE	(STERR | STDON | 0x14)
#define STATUS_ERR_INITFAILED	(STERR | STDON | 0x15)


typedef struct _DEVICE {

    struct {
	int	iorb_busy : 1;
	int	stopped : 1;			/* motor stopped */
	int	blocked : 1;			/* no I/Os, please */
    };

    USHORT	counter;			/* set to 0 on access,
						   incremented by timer */

    /* How to access this device... */

    void	(FAR *pADDEntry)(PIORB);
    USHORT	hdADDUnit;			/* ADD handle of this unit */
    USHORT	hdFilter;			/* previous filter (if any) */

    UNITINFO	modinfo;			/* modified unit info */
    USHORT	iAdapter;			/* global index */
    USHORT	iUnit;				/* per adapter index */

    /* Things to do I/Os with */

    USHORT	usSleep;			/* seconds until sleep */
    UCHAR	cdbStop[6];			/* for each unit because
						   LUN is included */
    UCHAR	cdbStart[6];
    UCHAR	cdbTestReady[6];

    USHORT		iotype;			/* really UCHAR, see pub.h */
    USHORT		laststatus;
    USHORT		lasterror;
    SCSI_STATUS_BLOCK	statusblock;		/* same segment as IORB! */
    SCSI_REQSENSE_DATA	sensedata;

    UCHAR	iorb[MAX_IORB_SIZE];		/* IORB to do start/stop */

    /* As we cannot block we need an IORB queue */

    PIORB	pQueueHead;
    PIORB	pQueueFoot;			/* IORB queueing */

} DEVICE, NEAR * NPDEVICE;




/*
 *	Debugging macros
 */

#if defined(DEBUG)
# define DEBMSG(msg)		dprintf((char _far *)msg)
# define DEBMSG1(msg,p1)	dprintf((char _far *)msg,p1)
# define DEBMSG2(msg,p1,p2)	dprintf((char _far *)msg,p1,p2)
# define DEBMSG3(msg,p1,p2,p3)	dprintf((char _far *)msg,p1,p2,p3)
# define DEBMSG4(msg,p1,p2,p3,p4) dprintf((char _far *)msg,p1,p2,p3,p4)
# define ERRMSG(msg)		dprintf((char _far *)msg); _asm {int 3}
# define ERRMSG1(msg,p1)	dprintf((char _far *)msg,p1); _asm {int 3}
# define ERRMSG2(msg,p1,p2)	dprintf((char _far *)msg,p1,p2); _asm {int 3}
# define ERRMSG3(msg,p1,p2,p3)	dprintf((char _far *)msg,p1,p2,p3); _asm {int 3}

#else
# define DEBMSG(msg)
# define DEBMSG1(msg,p1)
# define DEBMSG2(msg,p1,p2)
# define DEBMSG3(msg,p1,p2,p3)
# define DEBMSG4(msg,p1,p2,p3,p4)
# define ERRMSG(msg)
# define ERRMSG1(msg,p1)
# define ERRMSG2(msg,p1,p2)
# define ERRMSG3(msg,p1,p2,p3)
#endif /*DEBUG*/



#if defined(INFORM)
# define INFMSG(msg)		dprintf((char _far *)msg);
# define INFMSG1(msg,p1)	dprintf((char _far *)msg,p1);
# define INFMSG2(msg,p1,p2)	dprintf((char _far *)msg,p1,p2);
# define INFMSG3(msg,p1,p2,p3)	dprintf((char _far *)msg,p1,p2,p3);
# define INFMSG4(msg,p1,p2,p3,p4)	dprintf((char _far *)msg,p1,p2,p3,p4);

#else
# define INFMSG(msg)
# define INFMSG1(msg,p1)
# define INFMSG2(msg,p1,p2)
# define INFMSG3(msg,p1,p2,p3)
# define INFMSG4(msg,p1,p2,p3,p4)
#endif




#if defined(DEBUG)
# define DBSTOP()		_asm {int 3}
#else
# define DBSTOP()
#endif


#if defined(DEBUG)
# define DO(bef)		bef
#else
# define DO(bef)
#endif
