/*
 * $Source: e:/source/driver/sleep/RCS/proto.h,v $
 * $Revision: 1.6 $
 * $Date: 1997/07/21 01:32:26 $
 * $Author: vitus $
 *
 * Function prototyping
 *
 * $Log: proto.h,v $
 * Revision 1.6  1997/07/21 01:32:26  vitus
 * Added IssueStart,IssueStop from iorb.c
 *
 * Revision 1.5  1997/06/18 00:51:15  vitus
 * - changed FilterFunction to _saveregs
 * - added prototypes for MS-C inline functions (_disable,_enable)
 *
 * Revision 1.4  1997/05/07 23:47:21  vitus
 * - added dprintf prototype (debugging)
 *
 * Revision 1.3  1997/03/03 01:26:26  vitus
 * Added _far_strlen, SaveMessage
 *
 * Revision 1.2  1996/10/23 23:42:15  vitus
 * Added _far_mem*() functions
 *
 * Revision 1.1  1996/09/27 03:39:41  vitus
 * Initial revision
 * -------------------------------------------
 * This code is Copyright Vitus Jensen 1996-97
 */


/* MS-C inline functions (these take only near pointer!)
 * OBS: don't forget to compile w/ inlining (at least -Oi) */

void	 _disable(void);
void	 _enable(void);


/* Module: segments.asm */

extern void	NEAR AsmTimer(void);		/* really far */


/* Module: str1.c */

extern void	NEAR Strategy();
extern void	NEAR _far_memcpy(void _far *,void const _far *,USHORT);
extern void	NEAR _far_memset(void _far *,UCHAR,USHORT);
extern int	NEAR _far_memcmp(UCHAR const _far *,UCHAR const _far *,USHORT);
extern int	NEAR _far_strlen(UCHAR const _far *);
extern void	NEAR _far_strcpy(PUCHAR d,UCHAR const _far *s);


/* Module: ioctl.c */

extern void	NEAR SaveMessage(void);


/* Module: iorb.c */

extern int NEAR				IssueStart(NPDEVICE const device);
extern void NEAR			IssueStop(NPDEVICE const device);
extern void _saveregs _loadds FAR	FilterFunction(PIORB iorb);


/* Module: init.c */

extern USHORT	NEAR InitBase(PRPINITIN pRPI);


/* Module: printk.c */

extern void	NEAR sprintk(char FAR *outs,const char FAR *fmt,...);

#if defined(DEBUG)
/* Module: dprintf.asm */

extern void	NEAR dprintf(char FAR * msg,...);
#endif
