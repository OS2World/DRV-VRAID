/*
 * $Source: e:/source/driver/sleep/RCS/dskslpub.h,v $
 * $Revision: 1.1 $
 * $Date: 1997/02/06 01:07:05 $
 * $Author: vitus $
 *
 * Describes IOCtl interface to dsksleep.flt
 *
 * $Log: dskslpub.h,v $
 * Revision 1.1  1997/02/06 01:07:05  vitus
 * Initial revision
 *
 * -------------------------------------------
 * This code is Copyright Vitus Jensen 1996-97
 */

#if !defined(_DSKSLPUB_H)
#define _DSKSLPUB_H
#pragma pack(1)					/* all structures packed */


/*
 * IOCtl category and function codes
 */
#define IOCTL_DSKSLEEP_CATEGORY	0xC0		/* a user-defined category */
#define DSKSL_QUERY_VERSION	0x60		/* returns USHORT */
#define DSKSL_QUERY_TIMEOUT	0x61		/* return device list */
#define DSKSL_SET_TIMEOUT	0x41		/* changes single entry */


/* Defines device settings */
typedef struct _DEVICE_TIMEOUT {
    UCHAR	adapter;			/* adapter index */
    UCHAR	unit;				/* unit index */
    UCHAR	reserved[2];			/* (padding) */
    ULONG	minutes;			/* 0 -> no sleep */
} DEVICE_TIMEOUT;


/* Returned by DSKSL_QUERY_TIMEOUT */
typedef struct _DSKSL_QL_DATA {
    USHORT		cb;			/* byte count driver wants
						   to return (may be larger
						   than application buffer) */
    UCHAR		reserved[2];		/* (padding) */
    DEVICE_TIMEOUT	list[1];		/* some compiler don't
						   support '[]' ... */
} DSKSL_QL_DATA, * PDSKSL_QL_DATA;


/* Passed to DSKSL_SET_TIMEOUT */
typedef struct _DSKSL_SETTO_PARM {
    USHORT		cb;			/* size of complete structure */
    UCHAR		reserved[2];		/* (padding) */
    DEVICE_TIMEOUT	list[1];		/* see above */
} DSKSL_SETTO_PARM, * PDSKSL_SETTO_PARM;


#pragma pack()
#endif /* _DSKSLPUB_H */
