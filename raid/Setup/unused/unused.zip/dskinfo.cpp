

/*# ----------------------------------------------------------------------
 * CALL
 *	UpdateDsklayout(dsk)
 * PARAMETER
 *	dsk
 *
 * RETURNS
 *	(nothing)
 *
 * DESCRIPTION
 *	'dsk' has been changed by the user -> update physical storage.
 *
 * REMARKS
 */
PRIVATE VOID
UpdateDsklayout(PDSKINFO dsk)
{
    PUCHAR	buffer = new UCHAR[SECTOR_SIZE];
    USHORT	i;
    ULONG	ul;


    if( dsk->acc == DSKACC_NONE )		/* virtual drive? */
    {
	PSEC_VRDEV	sec = (PSEC_VRDEV)buffer;

	/* First: fill configuration sector of current level. */

	memset(sec, 0, sizeof(*sec));
	memcpy(sec->sectype, "VRAIDDEVICE     ", 16);
	sec->timestamp = time(NULL);

	memcpy(dsk->id, &usHostId, sizeof(usHostId));
	*(PULONG)&dsk->id[2] = time(NULL);
	memcpy(sec->u.s.id, dsk->id, sizeof(DEVID));

	sec->u.s.type = dsk->type;
	sec->u.s.flags = (dsk->parent != 0 ? 0 : 0x80);

	sec->u.s.childs = dsk->kind.vrd.childs;

	/* 2nd: recalculate drive size, correct size of childs.
	 * The current values were only wild guesses. */

	switch( dsk->type )
	{
	  case DSKTYPE_SINGLE:
	    dsk->size = dsk->kind.vrd.child[0]->size;
	    sec->u.s.child[0].size = dsk->kind.vrd.child[0]->size;
	    break;

	  case DSKTYPE_CHAIN:
	    dsk->size = 0;
	    for( i = 0; i < dsk->kind.vrd.childs; ++i )
	    {
		dsk->size += dsk->kind.vrd.child[i]->size;
		sec->u.s.child[i].size = dsk->kind.vrd.child[i]->size;
	    }
	    break;

	  case DSKTYPE_STRIPE:
	    dsk->size = 0;
	    ul = ULONG_MAX;
	    for( i = 0; i < dsk->kind.vrd.childs; ++i )
	    {
		ul = min(ul,dsk->kind.vrd.child[i]->size);
	    }
	    for( i = 0; i < dsk->kind.vrd.childs; ++i )
	    {
		sec->u.s.child[i].size = ul;
		dsk->size += ul;
	    }
	    break;

	  case DSKTYPE_MIRROR:
	    ul = ULONG_MAX;
	    for( i = 0; i < dsk->kind.vrd.childs; ++i )
	    {
		ul = min(ul,dsk->kind.vrd.child[i]->size);
	    }
	    for( i = 0; i < dsk->kind.vrd.childs; ++i )
	    {
		sec->u.s.child[i].size = ul;
	    }
	    dsk->size = ul;
	    break;

	  case DSKTYPE_RAID4:
	  case DSKTYPE_RAID5:
	  default:
	    assert(0);
	    break;
	}

	/* 3rd: update all childs and record their IDs. */

	for( i = 0; i < dsk->kind.vrd.childs; ++i )
	{
	    UpdateDsklayout(dsk->kind.vrd.child[i]);
	    memcpy(sec->u.s.child[i].id,
		   dsk->kind.vrd.child[i]->id, sizeof(DEVID));
	}

	/* Last: write administrative sector of current level. */

	sec->crc = Crc16(buffer, SECTOR_SIZE-2);
	DoPartitionIo(dsk, TRUE, 0, 1, buffer);
    } /* end[if(DSKACC_NONE)] */
    else
    {
	/* This is a device with direct relation to a physical device.
	 * Verify/write PHYSDEVICE sector. */

	dsk->ioSync();
    }

    delete[] buffer;
    return;
}

/*

	    strcpy(descr, "RAID 1 (Mirroring)");
	    strcpy(descr, "RAID 4");
	    strcpy(descr, "RAID 5");
	    */




/*# ----------------------------------------------------------------------
 * CALL
 *	DoAbsIo(dsk,write,secno,seccnt,buffer)
 * PARAMETER
 *	dsk		disk to access
 *	write
 *	secno		relativ to disk start
 *	seccnt
 *	buffer
 *
 * RETURNS
 *	APIRET
 *
 * DESCRIPTION
 *	Read/Writes sectors from anywhere on a disk.
 *
 * REMARKS
 */
PRIVATE APIRET
DoAbsIo(PDSKINFO const dsk,BOOL write,ULONG secno,ULONG seccnt,PVOID const buffer)
{
    APIRET rc;

    if( dsk->acc == DSKACC_OS2 )
    {
	if( write )
	    rc = PDskWrite(dsk->access.os2.hd, secno, seccnt, buffer);
	else
	    rc = PDskRead(dsk->access.os2.hd, secno, seccnt, buffer);
    }
    else
	rc = 0xFFFF;
    return rc;
}




/*# ----------------------------------------------------------------------
 * CALL
 *	DoPartitionIo(dsk,write,offset,count,buffer)
 * PARAMETER
 *	dsk		disk to access
 *	write		TRUE: write, FALSE: read
 *	offset		offset in partition
 *	count		how may sectors?
 *	buffer		data to write, read
 *
 * RETURNS
 *	APIRET
 *
 * DESCRIPTION
 *	Read/Writes sectors inside a VRAID partition.
 *
 * REMARKS
 */
PRIVATE APIRET
DoPartitionIo(PDSKINFO const dsk,BOOL write,ULONG offset,ULONG count,PVOID buffer)
{
    APIRET	rc;
    USHORT	i;

    if( dsk == NULL )
	return (write == TRUE ? 0 : 0xFFFF);	/* I/O to missing child, OK? */

    switch( dsk->acc )
    {
      case DSKACC_OS2:
	offset += dsk->kind.physical.partstart;
	if( write )
	    rc = PDskWrite(dsk->access.os2.hd, offset, count, buffer);
	else
	    rc = PDskRead(dsk->access.os2.hd, offset, count, buffer);
	break;

      case DSKACC_FLT:
        {
	    PUCHAR	p = (PUCHAR)buffer;

	    for( i = 0; i < count; ++i, p += SECTOR_SIZE )
	    {
		rc = DriverPhysIO(dsk->access.flt.hd, write, offset+i, buffer);
		if( rc != 0 )
		    break;
	    }
	}
	break;

	/* I/O to virtual device. */
      case DSKACC_NONE:
	rc = 0;
	for( i = 0; i < dsk->kind.vrd.childs; ++i )
	    rc |= DoPartitionIo(dsk->kind.vrd.child[i], write,
				offset+1, count, buffer);
	break;

      default:
	rc = 0xFFFF;
	break;
    }

    return rc;
}
