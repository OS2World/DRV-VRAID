/*
 * $Source: r:/source/driver/raid/RCS/dsklayout.h,v $
 * $Revision: 1.5 $
 * $Date: 1998/12/22 00:03:10 $
 * $Locker:  $
 *
 *	Describes layout of administrative disk sectors.
 *
 * $Log: dsklayout.h,v $
 * Revision 1.5  1998/12/22 00:03:10  vitus
 * - added missing "#pragma pack()".  Silly bug.
 *
 * Revision 1.4  1998/06/26 22:11:22  vitus
 * - removed flags from SEC_PHYSDEV
 *
 * Revision 1.3  1998/05/29 01:39:53  vitus
 * - changed definition of STRIPE,CHAIN
 * - SINGLE is now valid type of VRAIDDEVICE sector
 *
 * Revision 1.2  1998/04/08 01:05:01  vitus
 * - changed unnamed to named structures (IBM Compiler)
 * - added size to child definition
 * - removed bitfield usage (probs with different compilers)
 *
 * Revision 1.1  1998/03/10 02:25:09  vitus
 * Initial revision
 * -------------------------------------------
 * This code is Copyright Vitus Jensen 1997-98
 */

#ifndef _DSKSLAYOUT_H
#define _DSKSLAYOUT_H
#pragma pack(1)

#define SECTOR_SIZE		512


/*
 * Absolute sector 0 contains a standard partition table.
 * A single partition is defined starting at absolute sector 1
 * and including the rest of physical disk space.
 */
#define VRAID_PARTTYPE		0x7C

/*
 * Relative sectors 1 to n in partition are used for administrative data.
 * May become variable in non-alpha versions...
 */
#define VRAID_ADMINSECTORS	32


/*
 * Layout of master boot record sector,
 * imported from OS2DASD header file.
 */
typedef struct _PARTITIONENTRY {
    UCHAR	BootIndicator;
    UCHAR	BegHead;
    UCHAR	BegSector;			/* plus 2 bits BegCylinder */
    UCHAR	BegCylinder;
    UCHAR	SysIndicator;
    UCHAR	EndHead;
    UCHAR	EndSector;			/* plus 2 bits EndCylinder */
    UCHAR	EndCylinder;
    ULONG	RelativeSectors;
    ULONG	NumSectors;
} PARTITIONENTRY;


typedef struct _MBR {
    UCHAR	Pad[0x1BE];
    PARTITIONENTRY PartitionTable[4];
    USHORT	Signature;
} MBR, FAR * PMBR;




/*
 * All devices are marked with an unique ID.
 * This could be build from two byte host ID (sum of BIOS image) and
 * a time stamp (UNIX time = seconds since 1.1.1970) at creation of device.
 */
typedef UCHAR		DEVID[6];
typedef DEVID FAR *	PDEVID;


/*
 * First configuration sector defines this physical device.  Currently
 * only an ID is defined.
 * Sector type: "PHYSDEVICE      "
 */
typedef struct _SEC_PHYSDEV {
    UCHAR	sectype[16];			/* R: type of sector */
    ULONG	timestamp;			/* R: when written */
    union {
	char		dummy[490];
	struct {
	    DEVID	id;
	    USHORT	adminspace;		/* will be VRAID_ADMINSECTORS */
	    ULONG	size;			/* user size [sectors]} */
	} s;
    } u;
    USHORT		crc;			/* CRC16 */
} SEC_PHYSDEV, FAR * PSEC_PHYSDEV;




/*
 * Second and all further configuration sectors define
 * the VRDEVICES build upon this disk.
 * Sector type: "VRAIDDEVICE     "
 */
typedef struct _SEC_VRDEV {
    UCHAR	sectype[16];			/* R: type of sector */
    ULONG	timestamp;			/* R: when written */
    union {
	char		dummy[490];
	struct {
	    DEVID	id;
	    UCHAR	type;			/* RDTYPE_* */
	    UCHAR	flags;			/* bit 7: host drive */
	    USHORT	childs;			/* entries in following table */
	    struct {
		DEVID	id;
		ULONG	size;			/* [sectors] */
	    } child[1];
	} s;
    } u;
    USHORT		crc;			/* CRC16 */
} SEC_VRDEV, FAR * PSEC_VRDEV;


#define RDTYPE_SINGLE	1
#define RDTYPE_CHAIN	2
#define RDTYPE_STRIPE	3
#define RDTYPE_MIRROR	4
#define RDTYPE_RAID4	5
#define RDTYPE_RAID5	6

#pragma pack()
#endif /* _DSKSLAYOUT_H */
